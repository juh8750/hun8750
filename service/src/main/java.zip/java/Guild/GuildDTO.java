package Guild;

public class GuildDTO {
}
