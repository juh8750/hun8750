package Store;

public class StoreDTO {
}
