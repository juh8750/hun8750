package playerinfo;

import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.UUID;

public class PlayerDTO {
    PlayerInfo playerInfo;

    public PlayerInfo getPlayerInfo() {
        return  this.playerInfo;
    }

}