package service;

import org.bukkit.entity.Player;

public interface ControllerProvider {
    Contoller getController();
}
