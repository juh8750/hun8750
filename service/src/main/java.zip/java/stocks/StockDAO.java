package stocks;

import java.sql.*;
import java.util.*;
import java.math.BigDecimal;
import java.time.LocalDateTime;
import stocks.StockDTO;

public class StockDAO {

    private final Connection conn;

    public StockDAO(Connection conn) {
        this.conn = conn;
    }

    // ✅ getAllStocks
    public List<StockDTO> getAllStocks() {
        List<StockDTO> stocks = new ArrayList<>();
        String sql = "SELECT * FROM stocks WHERE delisted = FALSE";

        try (PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                stocks.add(new StockDTO(
                        rs.getString("symbol"),
                        rs.getString("name"),
                        rs.getBigDecimal("price"),
                        rs.getBigDecimal("change_rate"),
                        rs.getBoolean("delisted"),
                        rs.getTimestamp("last_updated").toLocalDateTime()
                ));
            }

        } catch (SQLException e) {
            System.err.println("[ERROR] getAllStocks 실패: " + e.getMessage());
        }

        return stocks;
    }

    // ✅ getStock
    public StockDTO getStock(String symbol) {
        String sql = "SELECT * FROM stocks WHERE symbol = ? AND delisted = FALSE";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, symbol);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new StockDTO(
                            rs.getString("symbol"),
                            rs.getString("name"),
                            rs.getBigDecimal("price"),
                            rs.getBigDecimal("change_rate"),
                            rs.getBoolean("delisted"),
                            rs.getTimestamp("last_updated").toLocalDateTime()
                    );
                }
            }

        } catch (SQLException e) {
            System.err.println("[ERROR] getStock 실패: " + e.getMessage());
        }

        return null;
    }

    // ✅ updateStockPrice
    public void updateStockPrice(String symbol, BigDecimal newPrice, BigDecimal changeRate) {
        String sql = "UPDATE stocks SET price = ?, change_rate = ?, last_updated = NOW() WHERE symbol = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setBigDecimal(1, newPrice);
            stmt.setBigDecimal(2, changeRate);
            stmt.setString(3, symbol);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("[ERROR] updateStockPrice 실패: " + e.getMessage());
        }

    }

    // ✅ getPortfolio
    public List<StockPortfolioDTO> getPortfolio(UUID uuid) {
        List<StockPortfolioDTO> portfolio = new ArrayList<>();
        String sql = "SELECT * FROM stock_portfolio WHERE uuid = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, uuid.toString());
            try (ResultSet rs = stmt.executeQuery()) {
                while (rs.next()) {
                    portfolio.add(new StockPortfolioDTO(
                            uuid,
                            rs.getString("stock_symbol"),
                            rs.getInt("quantity"),
                            rs.getBigDecimal("avg_price")
                    ));
                }
            }
        } catch (SQLException e) {
            System.err.println("[ERROR] getPortfolio 실패: " + e.getMessage());
        }

        return portfolio;
    }

    // ✅ getPortfolioItem
    public StockPortfolioDTO getPortfolioItem(UUID uuid, String symbol) {
        String sql = "SELECT * FROM stock_portfolio WHERE uuid = ? AND stock_symbol = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, uuid.toString());
            stmt.setString(2, symbol);
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new StockPortfolioDTO(
                            uuid,
                            rs.getString("stock_symbol"),
                            rs.getInt("quantity"),
                            rs.getBigDecimal("avg_price")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("[ERROR] getPortfolioItem 실패: " + e.getMessage());
        }

        return null;
    }

    // ✅ insertPortfolio
    public boolean insertPortfolio(UUID uuid, String symbol, int qty, BigDecimal avgPrice) {
        String sql = "INSERT INTO stock_portfolio (uuid, stock_symbol, quantity, avg_price) VALUES (?, ?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, uuid.toString());
            stmt.setString(2, symbol);
            stmt.setInt(3, qty);
            stmt.setBigDecimal(4, avgPrice);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("[ERROR] insertPortfolio 실패: " + e.getMessage());
        }

        return false;
    }

    // ✅ updatePortfolio
    public boolean updatePortfolio(UUID uuid, String symbol, int qty, BigDecimal avgPrice) {
        String sql = "UPDATE stock_portfolio SET quantity = ?, avg_price = ? WHERE uuid = ? AND stock_symbol = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, qty);
            stmt.setBigDecimal(2, avgPrice);
            stmt.setString(3, uuid.toString());
            stmt.setString(4, symbol);
            return stmt.executeUpdate() > 0;

        } catch (SQLException e) {
            System.err.println("[ERROR] updatePortfolio 실패: " + e.getMessage());
        }

        return false;
    }

    // ✅ deletePortfolio
    public boolean deletePortfolio(UUID uuid, String symbol) {
        String sql = "DELETE FROM stock_portfolio WHERE uuid = ? AND stock_symbol = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, uuid.toString());
            stmt.setString(2, symbol);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[ERROR] deletePortfolio 실패: " + e.getMessage());
        }

        return false;
    }

    // ✅ markAsDelisted
    public boolean markAsDelisted(String symbol) {
        String sql = "UPDATE stocks SET delisted = TRUE WHERE symbol = ?";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, symbol);
            return stmt.executeUpdate() > 0;
        } catch (SQLException e) {
            System.err.println("[ERROR] markAsDelisted 실패: " + e.getMessage());
        }

        return false;
    }

    // ✅ 가격 변동 로그 저장
    public void logPriceChange(String symbol, BigDecimal oldPrice, BigDecimal newPrice, BigDecimal changeRate) {
        String sql = "INSERT INTO stock_price_log (symbol, old_price, new_price, change_rate) VALUES (?, ?, ?, ?)";

        try (PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setString(1, symbol);
            stmt.setBigDecimal(2, oldPrice);
            stmt.setBigDecimal(3, newPrice);
            stmt.setBigDecimal(4, changeRate);
            stmt.executeUpdate();
        } catch (SQLException e) {
            System.err.println("[ERROR] 가격 로그 저장 실패: " + e.getMessage());
        }
    }
    public boolean insertOrUpdatePortfolio(UUID uuid, String symbol, int quantity, BigDecimal pricePerStock) {
        StockPortfolioDTO existing = getPortfolioItem(uuid, symbol);
        if (existing == null) {
            return insertPortfolio(uuid, symbol, quantity, pricePerStock);
        } else {
            int newQty = existing.getQuantity() + quantity;
            BigDecimal newAvg = (
                    existing.getAvgPrice().multiply(BigDecimal.valueOf(existing.getQuantity()))
                            .add(pricePerStock.multiply(BigDecimal.valueOf(quantity)))
            ).divide(BigDecimal.valueOf(newQty), 2, BigDecimal.ROUND_HALF_UP);

            return updatePortfolio(uuid, symbol, newQty, newAvg);
        }
    }
    public boolean updatePortfolioAfterSell(UUID uuid, String symbol, int quantity) {
        StockPortfolioDTO existing = getPortfolioItem(uuid, symbol);
        if (existing == null || existing.getQuantity() < quantity) return false;

        int newQty = existing.getQuantity() - quantity;
        if (newQty == 0) {
            return deletePortfolio(uuid, symbol);
        } else {
            return updatePortfolio(uuid, symbol, newQty, existing.getAvgPrice());
        }
    }


}

