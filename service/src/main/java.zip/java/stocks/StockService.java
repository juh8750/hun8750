package stocks;

import java.math.BigDecimal;
import java.util.*;

import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import service.Contoller;


public class StockService {
    private final StockDAO dao;
    private final Set<String> highVolatilityStocks = new HashSet<>(Arrays.asList("TSLA", "BTC"));
    private final Contoller controller; // 주입된 Controller
    public List<StockDTO> getAllStocks() {
        return dao.getAllStocks();
    }

    public StockDTO getStock(String symbol) {
        return dao.getStock(symbol);
    }

    public StockService(StockDAO dao, Contoller controller) {
        this.dao = dao;
        this.controller = controller;
    }

    public boolean buyStock(Player player, String symbol, int quantity) {
        UUID uuid = player.getUniqueId();
        StockDTO stock = dao.getStock(symbol);
        if (stock == null || stock.isDelisted()) return false;

        BigDecimal pricePerStock = stock.getPrice();
        BigDecimal totalCost = pricePerStock.multiply(BigDecimal.valueOf(quantity));
        int currentBalance = controller.getModel().getPlayerBalances().getOrDefault(uuid, 0);

        if (currentBalance < totalCost.intValue()) {
            player.sendMessage(ChatColor.RED + "잔액이 부족합니다.");
            return false;
        }

        // 돈 차감
        controller.getModel().minusMoney(player, totalCost.intValue());
        controller.updateScoreboard(player);

        // 포트폴리오 갱신
        boolean success = dao.insertOrUpdatePortfolio(uuid, symbol, quantity, pricePerStock);
        if (success) {
            player.sendMessage(ChatColor.GREEN + "주식 " + symbol + " " + quantity + "주를 매수했습니다.");
        }
        return success;
    }

    public boolean sellStock(Player player, String symbol, int quantity) {
        UUID uuid = player.getUniqueId();
        StockPortfolioDTO portfolio = dao.getPortfolioItem(uuid, symbol);
        if (portfolio == null || portfolio.getQuantity() < quantity) return false;

        StockDTO stock = dao.getStock(symbol);
        if (stock == null) return false;

        BigDecimal revenue = stock.getPrice().multiply(BigDecimal.valueOf(quantity)).setScale(2, BigDecimal.ROUND_HALF_UP);

        // 포트폴리오 갱신
        boolean success = dao.updatePortfolioAfterSell(uuid, symbol, quantity);
        if (!success) return false;

        // 돈 지급
        controller.getModel().addMoney(player, revenue.intValue());
        controller.updateScoreboard(player);
        player.sendMessage(ChatColor.YELLOW + "주식 " + symbol + " " + quantity + "주를 매도하여 " + revenue + "원을 받았습니다.");
        return true;
    }

    public void simulatePriceChanges() {
        List<StockDTO> stocks = dao.getAllStocks();
        for (StockDTO stock : stocks) {
            BigDecimal currentPrice = stock.getPrice();
            if (currentPrice == null) continue;

            double volatility = highVolatilityStocks.contains(stock.getSymbol()) ? 0.10 : 0.03;
            double changePercent = (Math.random() * 2 * volatility) - volatility;
            BigDecimal changeRate = BigDecimal.valueOf(changePercent * 100).setScale(2, BigDecimal.ROUND_HALF_UP);
            BigDecimal newPrice = currentPrice.multiply(BigDecimal.valueOf(1 + changePercent)).setScale(2, BigDecimal.ROUND_HALF_UP);

            dao.updateStockPrice(stock.getSymbol(), newPrice, changeRate);
            dao.logPriceChange(stock.getSymbol(), currentPrice, newPrice, changeRate);
        }
    }

    public List<StockPortfolioDTO> getPortfolio(Player player) {
        return dao.getPortfolio(player.getUniqueId());
    }

    public StockDTO findStockByNameOrSymbol(String input) {
        List<StockDTO> stocks = dao.getAllStocks();
        for (StockDTO stock : stocks) {
            if (stock.getSymbol().equalsIgnoreCase(input) || stock.getName().equalsIgnoreCase(input)) {
                return stock;
            }
        }
        return null;
    }

}

