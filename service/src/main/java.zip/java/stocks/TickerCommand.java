package stocks;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import stocks.TickerTask;

public class TickerCommand implements CommandExecutor {
    private final JavaPlugin plugin;
    private final TickerTask tickerTask;

    public TickerCommand(JavaPlugin plugin, TickerTask tickerTask) {
        this.plugin = plugin;
        this.tickerTask = tickerTask;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command cmd, String label, String[] args) {
        if (!(sender instanceof Player player)) return false;
        if (!player.isOp()) {
            player.sendMessage("\u00a7cOP\uB9CC 사용 가능한 명령입니다.");
            return true;
        }

        Location loc = player.getLocation();
        FileConfiguration config = plugin.getConfig();
        config.set("ticker.world", loc.getWorld().getName());
        config.set("ticker.x", loc.getBlockX());
        config.set("ticker.y", loc.getBlockY());
        config.set("ticker.z", loc.getBlockZ());
        plugin.saveConfig();

        tickerTask.reloadLocation();
        player.sendMessage("\u00a7a전광판 위치가 설정되었습니다.");
        return true;
    }
}
