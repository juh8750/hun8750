package tphuman;

import com.google.common.io.ByteArrayDataInput;
import com.google.common.io.ByteStreams;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;
import org.bukkit.plugin.messaging.PluginMessageListener;

import java.util.UUID;

public class TpnPluginMessageListener implements PluginMessageListener {

    public static final String CHANNEL = "guildchat:tpcoord";

    public TpnPluginMessageListener(JavaPlugin plugin) {
        plugin.getServer().getMessenger().registerIncomingPluginChannel(plugin, CHANNEL, this);
    }

    @Override
    public void onPluginMessageReceived(String channel, Player player, byte[] message) {
        if (!CHANNEL.equals(channel)) return;

        ByteArrayDataInput in = ByteStreams.newDataInput(message);
        UUID targetUuid = new UUID(in.readLong(), in.readLong());
        UUID senderUuid = new UUID(in.readLong(), in.readLong());

        Player target = Bukkit.getPlayer(targetUuid);
        Player sender = Bukkit.getPlayer(senderUuid);

        if (target != null && sender != null && target.getWorld().equals(sender.getWorld())) {
            sender.teleport(target.getLocation());
            sender.sendMessage(ChatColor.GREEN + "같은 서버 내 좌표 텔포 완료!");
        }
    }
}
